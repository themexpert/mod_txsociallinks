# mod_txsociallinks
This module is to show links with font-awosome icons.
